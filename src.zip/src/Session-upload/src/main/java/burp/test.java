package burp;

public class test {
    public static void main(String[] args) {
        String string = "GET /test/ssrf.php HTTP/1.1";
        System.out.println(string.replace("GET", "POST"));
    }
}
